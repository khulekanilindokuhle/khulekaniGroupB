package com.GroupB.GroupBWebApp.Entities;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import jakarta.persistence.Table;

import java.util.Date;

@Entity
@Table(name = "`Order`")
public class Order {

    @Id
    private int id;
    @Column
    private String items_list;
    @Column
    private int total_items;
    @Column
    private int product_list;
    @Column
    private double vat_amt;
    @Column
    private double vat_excluded;
    @Column
    private double total;
    @Column
    private Date date;

    public Order()
    {
    	 
    }
    
    // Parameterized constructor
    public Order(int id, String items_list, int total_items, int product_list, double vat_amt, double vat_excluded, double total, Date date) {
        this.id = id;
        this.items_list = items_list;
        this.total_items = total_items;
        this.product_list = product_list;
        this.vat_amt = vat_amt;
        this.vat_excluded = vat_excluded;
        this.total = total;
        this.date = date;
    }

    // Getters and setters
    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getItems_list() {
        return items_list;
    }

    public void setItems_list(String items_list) {
        this.items_list = items_list;
    }

    public int getTotal_items() {
        return total_items;
    }

    public void setTotal_items(int total_items) {
        this.total_items = total_items;
    }

    public int getProduct_list() {
        return product_list;
    }

    public void setProduct_list(int product_list) {
        this.product_list = product_list;
    }

    public double getVat_amt() {
        return vat_amt;
    }

    public void setVat_amt(double vat_amt) {
        this.vat_amt = vat_amt;
    }

    public double getVat_excluded() {
        return vat_excluded;
    }

    public void setVat_excluded(int vat_excluded) {
        this.vat_excluded = vat_excluded;
    }

    public double getTotal() {
        return total;
    }

    public void setTotal(int total) {
        this.total = total;
    }

    public Date getDate() {
        return date;
    }

    public void setDate(Date date) {
        this.date = date;
    }
}
