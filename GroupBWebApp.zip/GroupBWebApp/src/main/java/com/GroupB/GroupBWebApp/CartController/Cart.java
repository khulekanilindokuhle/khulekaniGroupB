package com.GroupB.GroupBWebApp.CartController;

import java.io.IOException;
import java.sql.Timestamp;
import java.util.Date;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import java.util.Random;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;

import com.GroupB.GroupBWebApp.Entities.Order;
import com.GroupB.GroupBWebApp.Repositories.OrderService;

import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;

@Controller
public class Cart {

	
	private Map<String, Item> cart = new HashMap<>();

	 
	 
    @PostMapping("/add-to-cart")
    @ResponseBody
    public void addToCart(HttpServletResponse response,HttpServletRequest request, @RequestParam("itemName") String itemName,
                            @RequestParam("price") int price,
                            @RequestParam("quantity") int quantity,
                            @RequestParam("page") int num) throws IOException {
    	
    	HttpSession session = request.getSession();
    	cart.put(itemName, new Item((price*quantity),quantity));
        
    	session.setAttribute("cart", cart);
    	
    	 
    	System.out.println("size: " + cart.size() + " " + (price*quantity) + " " + quantity + " " + itemName);
    	
    	if(num == 1)
    	{
    		response.sendRedirect("/menu");
    	}
        
    	else if(num==2)
    	{
    		response.sendRedirect("/burgers");
    	}
    	else if(num==3)
    	{
    		response.sendRedirect("/fries");
    	}
    	else if(num==4)
    	{
    		response.sendRedirect("/drinks");
    	}

    	else
    	{
    		response.sendRedirect("/desserts");
    	}
        
       
    }
    
    @PostMapping("/remove-item")
    @ResponseBody
    public void removeItem(HttpServletResponse response, HttpServletRequest request, @RequestParam("index") int index) throws IOException {
        HttpSession session = request.getSession();
        Map<String, Item> cart = (Map<String, Item>) session.getAttribute("cart");

        if (cart != null) {
            int currentIndex = 0;
            Iterator<Map.Entry<String, Item>> iterator = cart.entrySet().iterator();
            double totalPrice = 0; // Initialize total price

            while (iterator.hasNext()) {
                Map.Entry<String, Item> entry = iterator.next();
                if (currentIndex == index) {
                    Item item = entry.getValue();
                    int itemPricePerUnit = item.getPrice() / item.getQuantity(); // Calculate price per unit
                    
                    if (item.getQuantity() > 1) {
                        item.setQuantity(item.getQuantity() - 1); // Decrease the quantity by one
                        item.setPrice(item.getPrice() - itemPricePerUnit); // Decrease the total price of the item
                    } else {  
                        iterator.remove(); // Remove the item if quantity is zero
                    }
                    break; // Exit the loop once the item is found and processed
                }
                currentIndex++;
            }

            // Recalculate total price
            for (Item item : cart.values()) {
                totalPrice += item.getPrice();
            }
 
            session.setAttribute("cart", cart);
            session.setAttribute("totalPrice", totalPrice); // Update the total price in the session
            response.sendRedirect("/cart");
        }
    }

    @Autowired
    private OrderService orderService;
    
    @PostMapping("/order-number")
    @ResponseBody
    public void orderNumber(HttpServletResponse response, HttpServletRequest request) throws IOException {
      
    	HttpSession session = request.getSession();
          
        Random rand = new Random();
        int num = rand.nextInt(99000)+ 1000;//1
        session.setAttribute("num", num);
        
        Map<String, Item> cart = (Map<String, Item>)session.getAttribute("cart");
   	   
        int totItems = 0;  
        int amount = 0; 
        int vatAmt=0;
        int vatExc=0; 
        int index=0;  
        String list ="";
        for (Map.Entry<String, Item> en : cart.entrySet()) {
            String name = en.getKey();
            Item item = en.getValue();
            int quantity = item.getQuantity();
            int price = item.getPrice();
            int unit = (item.getPrice() / item.getQuantity());

            list+=en.getKey() +" R" + price + "\n";//2 
            totItems += quantity;//3
            amount += price;//7
        }
        
        vatAmt = (amount * 15)/100;//5
        vatExc = amount - vatAmt;//6
   	    System.out.println("SIZE  " + cart.size());//4
   	    Date date = new Date();
   	    Timestamp time = new Timestamp(date.getTime());
   	    
   	    
   	    Order order = new Order(num, list, totItems, cart.size(), vatAmt, vatExc, amount, time);
   	    orderService.saveOrder(order);
        response.sendRedirect("/order");
        
        }
     
@PostMapping("/summary_details")
@ResponseBody
public void orderSummary(HttpServletResponse response, HttpServletRequest request) throws IOException {
  
	HttpSession session = request.getSession();
  
	 Map<String, Item> cart = (Map<String, Item>)session.getAttribute("cart");
	 System.out.println(cart.size());
     session.setAttribute("cart", cart);
    
    response.sendRedirect("/summary");
    
    }
}


