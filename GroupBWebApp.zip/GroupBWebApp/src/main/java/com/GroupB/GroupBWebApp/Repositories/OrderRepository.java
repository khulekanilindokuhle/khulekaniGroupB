package com.GroupB.GroupBWebApp.Repositories;

import org.springframework.data.jpa.repository.JpaRepository;

import com.GroupB.GroupBWebApp.Entities.Order;

public interface OrderRepository extends JpaRepository<Order, Integer>{

}
