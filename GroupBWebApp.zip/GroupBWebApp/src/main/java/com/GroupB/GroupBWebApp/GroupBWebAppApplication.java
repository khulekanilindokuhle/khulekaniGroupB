package com.GroupB.GroupBWebApp;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.ComponentScan;

@SpringBootApplication
@ComponentScan("com.GroupB.GroupBWebApp")
public class GroupBWebAppApplication {

	public static void main(String[] args) {
		SpringApplication.run(GroupBWebAppApplication.class, args);
	}

}
