package com.GroupB.GroupBWebApp.Controller;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;

@Controller
public class loginController {

	@RequestMapping(value ="/index", method = RequestMethod.GET)
	public String indexPage()
	{
		return "index";
	}
	
	@RequestMapping(value = "/menu", method = RequestMethod.GET)
	public String menuPage() {
	    return "menu";
	}
	
	@RequestMapping(value = "/burgers", method = RequestMethod.GET)
	public String burgersPage() {
	    return "burgers";
	}
	
	@RequestMapping(value = "/drinks", method = RequestMethod.GET)
	public String drinksPage() {
	    return "drinks";
	}

	
	@RequestMapping(value = "/fries", method = RequestMethod.GET)
	public String friesPage() {
	    return "fries";
	}

	@RequestMapping(value = "/desserts", method = RequestMethod.GET)
	public String dessertsPage() {
	    return "desserts";
	}

	@RequestMapping(value = "/cart", method = RequestMethod.GET)
	public String cartPage() {
	    return "cart";
	}

	@RequestMapping(value = "/order", method = RequestMethod.GET)
	public String orderPage() {
	    return "order";
	}
	 
	@RequestMapping(value ="/index", method = RequestMethod.POST)
	public String WelcomePage(ModelMap model ,@RequestParam String id , String password)
	{
		
		if(id.equals("app") && password.equals("123")) {
			return "welcome";
		}
		
		model.put("errorMsg", "Provide correct login details");
		return "login";
	}
	
	@RequestMapping(value = "/summary", method = RequestMethod.GET)
	public String summaryPage() {
	    return "summary";
	}



}
