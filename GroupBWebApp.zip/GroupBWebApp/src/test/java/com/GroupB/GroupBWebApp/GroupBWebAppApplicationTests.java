package com.GroupB.GroupBWebApp;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class GroupBWebAppApplicationTests {

	@Test
	void contextLoads() {
	}

}
